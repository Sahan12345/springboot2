# SpringBootIn50
Source code for https://www.youtube.com/watch?v=Ke7Tr4RgRTs

# Instructions
1. Open pom.xml with Intelij or Eclipse
2. Run Main.java
3. Open browser on http://localhost:8080
